import React, { Component } from 'react';
import './App.css';
import { PageHeader, Row, Grid, Col } from 'react-bootstrap'
import Score from './components/Score'
import images from './images.json'
import ImageContainer from './components/ImageContainer'



// points.sort(function(a, b){return 0.5 - Math.random()});

class App extends Component {
    constructor(props){
      super(props)
      this.state = {
      score: 0,
      highestScore: 0,
      images: images
      }
      this.updateImage = this.updateImage.bind(this)
    }
    
  updateImage(imgName){
    console.log(imgName)
    if(!imgName.clicked){
      this.setState({imgName.clicked: 1})
    } else {
      console.log('Already clicked!')
    }
  }
  render() {
    console.log(images)
    return <div className="App container">
        <PageHeader>
          React Memory Game<br></br><small>Click the images to increase your score, but don't click the same one twice!</small>
        </PageHeader>
        <Score score={this.state.score} highestScore={this.state.highestScore}/>
        <ImageContainer updateImage={this.updateImage} images={this.state.images} />
      </div>;
  }
}

export default App;
