import React from 'react';
import "./styles.css";

const Image = props => {
    const handleClick = e => props.updateImage(e.target)
    return (
        <div>
            <img onClick={handleClick} clicked={props.clicked} key={props.id} className='image' alt={props.name} src={props.image}/>
        </div>
    );
};

export default Image;